#coding: utf-8
infile = "../data/data.json"
outfile = "../result/result.json"
def main():
    data = open(infile,"r")
    result = open(outfile,"w")

if __name__ == '__main__':
    main()

# -*- encoding: utf-8 -*-

"""
@File    :main.py
@Time    :2021/7/24 10:15
@Author  :hyyd
@Software: PyCharm
"""
import os
import random


def mkdir(root):
    """
    给定一个路径，递归创建路径中的目录。
    如果给到的root不是一个dir_path而是一个file_path则提取相应的路径名进行文件夹的创建
    :param root:路径名
    :return:
    """
    if not os.path.isdir(root):
        # 不是目录的路径，则提取路径中的目录
        root = os.path.split(root)[0]
    if not os.path.exists(root):
        # 不存在则创建路径中的目录
        os.makedirs(root)


def txt_to_list(file_path):
    """
    按行读取txt中的内容
    :param file_path: 路径地址
    :return:
    """
    with open(file_path, "r", encoding="utf-8") as fin:
        return [row_data.strip() for row_data in fin.readlines()]


def matrix_to_txt(file_path, matrix, sep=" "):
    """
    二维数组按照矩阵的方式存入txt中
    :param sep:
    :param file_path:
    :param matrix:
    :return:
    """
    """二维列表存储到txt中"""
    mkdir(file_path)
    with open(file_path, "w", encoding='utf-8') as fout:
        for row_data in matrix:
            fout.write(sep.join([str(ele) for ele in row_data]) + "\n")


if __name__ == '__main__':
    input_path = 'input'
    output_path = 'output'
    input_filename = 'SMP-CAIL2021-focus_recognition-test1.txt'
    output_filename = 'result1.txt'
    label_filename = 'labels.txt'
    input_file = input_path + '/' + input_filename
    output_file = output_path + '/' + output_filename
    label_file = input_path + '/' + label_filename

    corpus = txt_to_list(input_file)
    corpus_size = len(corpus)

    label_list = txt_to_list(label_file)

    result = []
    for _ in range(corpus_size):
        sample_num = random.randint(0, 3)
        pred = random.sample(label_list, sample_num)
        result.append(pred)

    matrix_to_txt(output_file, result)

#coding: utf-8
infile = "/input/input.json"
outfile = "/result/output.json"
def main():
    data = open(infile,"r")
    result = open(outfile,"w")

if __name__ == '__main__':
    main()